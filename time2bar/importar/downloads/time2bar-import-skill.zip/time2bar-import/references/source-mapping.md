# Mapeo de fuentes tabulares

Construir el mapeo desde la evidencia de cada fuente. Los nombres y ejemplos de
este documento son patrones frecuentes, no un esquema obligatorio.

## Determinar la granularidad

1. Identificar las columnas candidatas a fecha/hora, sesión, ejercicio, serie,
   resultado, esfuerzo, descanso, variante y notas.
2. Comparar varias filas:
   - Ejercicio repetido con índices de serie distintos → fila por serie.
   - Una expresión como `5x3` y un ejercicio único → fila por ejercicio.
   - Una fila sin ejercicio y con notas generales → fila de sesión.
   - Un único total sin desglose → observación agregada.
3. Agrupar por el identificador de sesión más explícito disponible. Preferir un
   ID o nombre de sesión; después fecha/hora y campos de día/bloque. No unir
   automáticamente dos sesiones solo porque comparten fecha.

## Resolver identidades de ejercicio

1. Inventariar todas las denominaciones e IDs antes de emitir ejercicios,
   rutinas o workouts.
2. Considerar identidad fuerte, por orden:
   - el mismo ID explícito de la fuente;
   - una relación de alias declarada por la fuente o el usuario;
   - una equivalencia semántica inequívoca apoyada por variante y contexto;
   - el mismo nombre normalizado, solo cuando no contradiga otra evidencia.
3. No consolidar por mera similitud textual. Una progresión, una asistencia, un
   agarre o una variante de ejecución pueden ser la misma identidad o ejercicios
   distintos según la fuente.
4. Elegir un único nombre canónico por identidad a partir de los datos
   disponibles. Guardar el resto de nombres literales en `aliases` y conservar
   detalles de ejecución en notas o `customValues`.
5. Emitir una única definición superior por identidad. Hacer que cada
   `routines[].exercises[]` y `workouts[].exercises[]` repita exactamente su
   `name` canónico y apunte al mismo `externalExerciseId`.
6. Mantener separadas las identidades dudosas y añadir un warning que explique
   qué dato permitiría unirlas. No usar un mismo ID para alternativas separadas
   por “o” sin evidencia adicional.
7. Elegir la métrica de biblioteca desde la definición más explícita o
   recurrente. Una serie atípica no debe cambiarla; conservar esa observación en
   el set y avisar si es incompatible.

## Resolver campos

- Tratar unidades y sufijos como evidencia: `10s` sugiere hold; `10 kg`, carga.
- Interpretar `rpe`, `dif` o `difficulty` según la granularidad demostrada:
  - fila por serie → RPE de set;
  - fila por ejercicio → RPE de ejercicio;
  - fila de sesión o columna declarada global → RPE de workout.
- Una lista como `7,6,7` puede ser RPE por serie cuando se alinea con tres sets.
  Si no se alinea, conservar posiciones seguras y emitir un warning.
- Mapear notas al nivel más específico que describan. Una variante, dolor o
  sustitución suele pertenecer al ejercicio; un resumen global, a la sesión.
- Interpretar descansos como planificados solo cuando la fuente lo indique. No
  convertir una duración observada en descanso planificado.
- Quitar prefijos como `A1` o `B2` del nombre únicamente cuando se repitan como
  etiquetas estructurales. Conservar su orden o bloque por separado.
- Guardar contexto útil sin destino de primer nivel —semana, bloque o etiqueta
  original— en `customValues` o notas, en vez de descartarlo.

## Notaciones frecuentes

Aplicar estas expansiones solo cuando el contexto confirme su significado:

- `5x1` → cinco sets de una rep.
- `1x6+1x4` → dos sets, de 6 y 4 reps.
- `3x4s` → tres holds de cuatro segundos.
- `3x4 por pierna` → tres sets con cuatro reps por lado.
- `3 por pierna` no declara sets: conservar como `legacyAggregate` y avisar.
- `3 series` → tres sets registrados sin inventar reps o tiempo.
- `acumulado 40 s` → volumen histórico agregado de 40 segundos.
- `XX`, `omitido` o `no realizado` → `skipped` solo si la fuente usa el valor
  como marcador de no ejecución; de lo contrario, conservarlo con warning.

Guardar una notación desconocida en `customValues.registroOriginal` cuando sea
posible. No descartarla ni completar sus huecos por intuición.

## Estado y rutinas

- Usar `partial`, `completed` o `abandoned` solo con evidencia explícita o con
  ejercicios marcados inequívocamente como no realizados.
- Representar objetivos de tiempo total con `structure: "accumulation"`.
- No elegir silenciosamente un extremo de rangos de rondas o descanso.
  Conservar la regla en `notes` y añadir un warning.
- No prometer alternancia de superseries o progresión multisemana si el contrato
  solo puede representar una sesión plana actual.

## Confianza

Aplicar directamente mapeos explícitos. Para inferencias razonables, conservar
el dato y añadir un warning. Si dos interpretaciones cambian materialmente
series, métrica o estado, no elegir una en silencio: omitir solo la parte
ambigua y explicar qué necesita confirmación.

Antes de responder, comprobar estas invariantes:

- un `externalId` superior por identidad;
- ningún `externalExerciseId` huérfano;
- un solo nombre canónico para cada ID en todo el documento;
- ningún ID compartido por ejercicios cuya equivalencia sea dudosa;
- aliases y detalles originales conservados sin convertirlos en identidades
  adicionales.
